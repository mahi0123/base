import { Time } from "@angular/common";


export class merchant{
    merchantId:number;
    merchantName: string;
    mobileNumber: number;
    email :string;
    password :string;
    catogory:string;
    productName:string;
    addMerchantDate:Date;
    logintime:Time;
    logouttime:Time;



}



