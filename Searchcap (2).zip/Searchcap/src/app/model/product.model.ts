import { Time } from "../../../node_modules/@angular/common";

export class Product {
   
pname:string;
pprice: number;
ratings: string;
discount: number;

feedback: string;

}



