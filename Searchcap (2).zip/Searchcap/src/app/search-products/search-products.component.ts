import { FormGroup, FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Product } from '../model/product.model';
import { ProductService } from '../service/product.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-search-products',
  templateUrl: './search-products.component.html',
  styleUrls: ['./search-products.component.css']
})
export class SearchProductsComponent implements OnInit {
 
  
  searchProductForm: FormGroup;
  products: Product[];
  productsByCategory: Product[];
  public searchText:any;
  constructor(private fb: FormBuilder, private productServ: ProductService) { }

  ngOnInit() {

    this.searchProductForm = this.fb.group({
      category: []
    });
    this.productServ.getallProducts()

    .subscribe(data=>{ //subscribe method observes all the changes and update teh changes
  
    //this.products = this.products.filter(u=> u!==product);
  
    this.products=data
  
     });
  }
  // onSearchClick() {
  //   this.productServ.getProducts(86).subscribe(
  //     data => {
  //       this.products = data;
  //       this.productsByCategory = this.products.filter(u => u.category == this.searchProductForm.value.category);
  //     }
  //   )
  // }
}
