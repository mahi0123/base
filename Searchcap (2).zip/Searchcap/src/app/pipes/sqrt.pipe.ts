import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'nname'
})
export class SqrtPipe implements PipeTransform {

  transform(usersList: any, searchText2: any){

    if(searchText2){
      console.log(usersList.pname);
      console.log(usersList.cname);
    return  usersList.filter(x=>(x.cname).toLowerCase().startsWith(searchText2.toLowerCase()));}
  }

}
