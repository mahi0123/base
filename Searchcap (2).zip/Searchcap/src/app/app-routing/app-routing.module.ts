import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchProductsComponent } from '../search-products/search-products.component';
import { SearchCustomersComponent } from '../search-customers/search-customers.component';
import { SearchMerchantComponent } from '../search-merchant/search-merchant.component';


const routes: Routes = [

  
    {path:'search-products',component: SearchProductsComponent},
// {path:'list-emp',component:ListEmpComponent}
    // path: 'search',
    // component: SearchProductsComponent
    {path:'search-customers',component: SearchCustomersComponent},
    {path:'search-merchant',component: SearchMerchantComponent}
]
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],


  exports: [RouterModule],
  declarations: []
})
  
export class AppRoutingModule { }
