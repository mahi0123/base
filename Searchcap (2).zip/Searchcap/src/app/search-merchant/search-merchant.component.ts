// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-search-merchant',
//   templateUrl: './search-merchant.component.html',
//   styleUrls: ['./search-merchant.component.css']
// })
// export class SearchMerchantComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }



import { FormGroup, FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Product } from '../model/product.model';
import { merchantService } from '../service/product.service';
import { Router } from '../../../node_modules/@angular/router';
import { merchant } from '../model/merchant.model';

@Component({
  selector: 'app-search-merchant',
  templateUrl: './search-merchant.component.html',
  styleUrls: ['./search-merchant.component.css']
})
export class SearchMerchantComponent implements OnInit {
 
  
  searchMerchantForm: FormGroup;
  merchants: merchant[];
  merchantsByCategory: merchant[];
  public searchText:any;
  constructor(private fb: FormBuilder, private merchantServ: merchantService) { }

  ngOnInit() {

    this.searchMerchantForm = this.fb.group({
      category: []
    });
    this.merchantServ.getallmerchants()

    .subscribe(data=>{ //subscribe method observes all the changes and update teh changes
  
    //this.products = this.products.filter(u=> u!==product);
  
    this.merchants=data
  
     });
  }
  // onSearchClick() {
  //   this.productServ.getProducts(86).subscribe(
  //     data => {
  //       this.products = data;
  //       this.productsByCategory = this.products.filter(u => u.category == this.searchProductForm.value.category);
  //     }
  //   )
  // }
}

