package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.SearchAdminDaoInterface;
import com.cg.entity.CustomerEntity;
import com.cg.entity.MerchantEntity;
import com.cg.entity.ProductEntity;

@Transactional
@Service
public class SearchServiceImplementation implements SearchServiceInterface{
     @Autowired SearchAdminDaoInterface ae;
     CustomerEntity ce;
     MerchantEntity me;
     ProductEntity pe;
     
	@Override
	public List<CustomerEntity> findCustomerByName(String Name) {
		
		return ce.findCustomerByName(Name);
	}

	@Override
	public List<MerchantEntity> findMerchantByName(String merchantName) {
		
		return me.findMerchantByName(merchantName);
	}

	@Override
	public List<ProductEntity> findProducts(String userData) {
		
		return pe.findProducts(userData);
	}

	@Override
	public List<ProductEntity> findAllProducts(String merchantId) {
		return pe.findAllProducts(merchantId);
	}

}
