package com.cg.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.context.annotation.Configuration;

@XmlRootElement
@Entity
	@Table(name="customer_login")
	
	public class CustomerEntity {
		
		@Id
		String email_Id;
		@NotNull
		String password;
		String name;
		long phoneNumber;
		String address;
		
		@PersistenceContext
		EntityManager entityManager;
		public String getEmail_Id() {
			return email_Id;
		}
		public void setEmail_Id(String email_Id) {
			this.email_Id = email_Id;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		
		public long getPhoneNumber() {
			return phoneNumber;
		}
		public void setPhoneNumber(long phoneNumber) {
			this.phoneNumber = phoneNumber;
		}
		@Override
		public String toString() {
			return "CustomerEntity [email_Id=" + email_Id + ", password=" + password + ", name=" + name + ", address="
					+ address + ", phoneNumber=" + phoneNumber + "]";
		}
		public List<CustomerEntity> findCustomerByName(String name2) {
			System.out.println("in dao");
			TypedQuery<CustomerEntity> query = entityManager.createQuery("SELECT customerdetails FROM CustomerEntity customerdetails where customerdetails.name =?1", CustomerEntity.class);
			query.setParameter(1, findCustomerByName(name));
			List<CustomerEntity> customerList = new ArrayList<CustomerEntity>();
			customerList = query.getResultList();
			return customerList;
		}
		
		
}
