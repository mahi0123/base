package com.cg.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.context.annotation.Configuration;

@XmlRootElement

	@Entity
	@Table(name="merchant_login")
	public class MerchantEntity {
		
		@Id
		String email_Id;
		@NotNull
		String password;
		String name;
		String address;
		@Column(name="Organization_name")
		String organization_name;
		long phoneNumber;
		
		
		@PersistenceContext
		EntityManager entityManager;
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getOrganization_name() {
			return organization_name;
		}
		public void setOrganization_name(String organization_name) {
			this.organization_name = organization_name;
		}
		public String getEmail_Id() {
			return email_Id;
		}
		public void setEmail_Id(String email_Id) {
			this.email_Id = email_Id;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		
		public long getPhoneNumber() {
			return phoneNumber;
		}
		public void setPhoneNumber(long phoneNumber) {
			this.phoneNumber = phoneNumber;
		}
		@Override
		public String toString() {
			return "MerchantEntity [email_Id=" + email_Id + ", password="
					+ password + ", name=" + name + ", address=" + address
					+ ", Organization_name=" + organization_name + ", phoneNumber="
					+ phoneNumber + "]";
		}
		public List<MerchantEntity> findMerchantByName(String merchantName) {
			System.out.println(merchantName);
			TypedQuery<MerchantEntity> query = entityManager.createQuery("select merchantdetails from MerchantEntity merchantdetails where merchantdetails.name =?1", MerchantEntity.class);
			query.setParameter(1, merchantName);
			List<MerchantEntity> merchantList = new ArrayList<MerchantEntity>();
			merchantList = query.getResultList();
			System.out.println("merchant fetched");
			return merchantList;
		}
	
}
