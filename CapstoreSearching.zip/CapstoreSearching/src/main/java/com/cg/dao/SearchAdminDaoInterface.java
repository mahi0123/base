package com.cg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.cg.entity.AdminEntity;


public interface SearchAdminDaoInterface extends JpaRepository<AdminEntity,String>{
	
	
	
}
