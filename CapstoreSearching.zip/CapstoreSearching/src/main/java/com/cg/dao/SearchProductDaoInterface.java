package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.entity.ProductEntity;



public interface SearchProductDaoInterface  extends JpaRepository<ProductEntity,Integer> {

}
