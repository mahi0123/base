package com.cg.dao;

import java.util.List;

import com.cg.entity.CustomerEntity;
import com.cg.entity.MerchantEntity;
import com.cg.entity.ProductEntity;

public interface SearchDaoInterface {
	
	
	public List<CustomerEntity> findCustomerByName(String name);
	public List<MerchantEntity> findMerchantByName(String merchantName);
	public List<ProductEntity> findProducts(String userData);
	public List<ProductEntity> findAllProducts(String merchantId);

}
