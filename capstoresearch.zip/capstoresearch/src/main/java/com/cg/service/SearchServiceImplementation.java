package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;

import com.cg.dao.SearchDaoInterface;
import com.cg.entity.CustomerEntity;
import com.cg.entity.MerchantEntity;
import com.cg.entity.ProductEntity;

@Configuration
@Transactional
@Service
public class SearchServiceImplementation implements SearchServiceInterface {
	@Autowired
	
	SearchDaoInterface dao;
	@Override
	public List<CustomerEntity> findCustomerByName(String Name) {
		
		 return dao.findCustomerByName(Name);
	}

	@Override
	public List<MerchantEntity> findMerchantByName(String merchantName) {
		
		return dao.findMerchantByName(merchantName);
	}

	@Override
	public List<ProductEntity> findProducts(String userData) {
	
		return dao.findProducts(userData);
	}

	@Override
	public List<ProductEntity> findAllProducts(String merchantId) {
		
		return dao.findAllProducts(merchantId);
	}
	
	

}
