package com.cg.service;

import java.util.List;

import com.cg.entity.CustomerEntity;
import com.cg.entity.MerchantEntity;
import com.cg.entity.ProductEntity;

public interface SearchServiceInterface {
	

	public List<CustomerEntity> findCustomerByName(String Name);
	public List<MerchantEntity> findMerchantByName(String merchantName);
	public List<ProductEntity> findProducts(String userData);
	public List<ProductEntity> findAllProducts(String merchantId);

}
