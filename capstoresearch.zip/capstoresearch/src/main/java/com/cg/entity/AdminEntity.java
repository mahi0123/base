package com.cg.entity;

import javax.persistence.*;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.context.annotation.Configuration;

    //@Configuration
	@Table(name="admin_login")
	@Entity
	public class AdminEntity {
		
		@Id
		String email_Id;
		@NotNull
		String password;
		@NotNull
		String name;
		@NotNull
		long phoneNumber;
		
		
		public String getEmail_Id() {
			return email_Id;
		}
		public void setEmail_Id(String email_Id) {
			this.email_Id = email_Id;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		
		public long getPhoneNumber() {
			return phoneNumber;
		}
		public void setPhoneNumber(long phoneNumber) {
			this.phoneNumber = phoneNumber;
		}
		@Override
		public String toString() {
			return "AdminEntity [email_Id=" + email_Id + ", password=" + password + ", name=" + name + ", phoneNumber="
					+ phoneNumber + "]";
		}
		
	}	
		


