package com.cg.entity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import org.springframework.context.annotation.Configuration;

//@Configuration

	@Table(name="customer_login")
	@Entity
	public class CustomerEntity {
		
		@Id
		@Column(name="email_Id")
		String email_Id;
		@NotNull
		@Column(name="password")
		String password;
		@Column(name="name")
		String name;
		@Column(name="phoneNumber")
		long phoneNumber;
		@Column(name="address")
		String address;
		
		
		public String getEmail_Id() {
			return email_Id;
		}
		public void setEmail_Id(String email_Id) {
			this.email_Id = email_Id;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		
		public long getPhoneNumber() {
			return phoneNumber;
		}
		public void setPhoneNumber(long phoneNumber) {
			this.phoneNumber = phoneNumber;
		}
		@Override
		public String toString() {
			return "CustomerEntity [email_Id=" + email_Id + ", password=" + password + ", name=" + name + ", address="
					+ address + ", phoneNumber=" + phoneNumber + "]";
		}
		
		
}
