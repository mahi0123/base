package com.cg.wallateapp.exception;

public class WalletException extends RuntimeException {
	public WalletException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public WalletException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
