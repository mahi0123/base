package com.cg.wallateapp.service;

import java.util.List;

import com.cg.wallateapp.entities.Account;
import com.cg.wallateapp.exception.WalletException;

public interface AccountService {
	public void createAccount(Account ac);
	public void add(double amount,Integer mobilNO);
	public void withdraw(double amount,Integer mobilNO);
	//public Account updateAccount(Account ac)throws WalletException;
	public void delete(Integer mobileNumber) throws WalletException;
	public void transferMoney(Integer mob1,Integer mob2 ,Double amount);
	public Account getAccountBymobile(Integer mobileNo) throws WalletException;
	public List<Account> getAllAccounts();
	public double getBalance(Integer acno);
}
