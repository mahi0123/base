package com.cg.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.app.dao.ReferFriendDao;
import com.cg.app.model.ReferFriend;
@Service
public class ReferFriendServiceImpl implements ReferFriendService{

	@Autowired ReferFriendDao dao;
	@Override
	@Transactional(readOnly=true)
	public ReferFriend findByid(String id) {
		// TODO Auto-generated method stub
		Optional<ReferFriend> temp = dao.findById(id);
		return temp.get();
	}
	@Override
	public void update(ReferFriend rf) {
		
		List<ReferFriend> elist = dao.findAll();
		for(ReferFriend e : elist)
			if(e.getCustName().equals(rf.getReferredby()))
			{
				double rew = e.getRewards();
				e.setRewards(rew+300);
			}
		dao.save(rf);
	}
	@Override
	public List<ReferFriend> findAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

}
