package com.cg.app.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.app.model.ReferFriend;

@Repository
public interface ReferFriendDao  extends JpaRepository<ReferFriend, String>{

}
