package com.cg.app.controllers;

import java.text.ParseException;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.app.model.CapStoreAccount;
import com.cg.app.model.CouponGenerator;
import com.cg.app.services.CapStoreAccountService;
import com.cg.app.services.CapStoreService;
import com.cg.app.services.CapStoreServiceImpl;

@RestController
@RequestMapping("/store")
public class CapStoreController {
	@Autowired CapStoreService cap;
	       CapStoreAccountService cap1;
	//@Autowired CouponGenerator c;
	
	 
	@PostMapping(value="/create" )
	public ResponseEntity<String> create() {
		//System.out.println("hvghj");
			cap.createCoupon();
				return new ResponseEntity<String>("Coupon Sent to Email",HttpStatus.CREATED);
	}
	@PostMapping(value="/createAccount" )
	public ResponseEntity<String> createAccount(@RequestBody CapStoreAccount c) {
		//System.out.println("hvghj");
			cap1.createAccount(c);
				return new ResponseEntity<String>("Account created",HttpStatus.CREATED);
	}
	/*@PostMapping(value="/update/{acno}/{amount}" )
	public ResponseEntity<String> createAccount(@PathVariable String acno,@PathVariable double amount) {
		//System.out.println("hvghj");
			cap1.addMoney(acno,amount);
				return new ResponseEntity<String>("Account created",HttpStatus.CREATED);
	}*/
	
}


