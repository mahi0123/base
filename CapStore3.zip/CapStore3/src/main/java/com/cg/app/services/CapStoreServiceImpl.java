package com.cg.app.services;

import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Random;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.app.dao.CapStoreDao;
import com.cg.app.model.CouponGenerator;
@Service
@Transactional
public class CapStoreServiceImpl implements CapStoreService {
@Autowired private CapStoreDao dao;
	

		
	
	@Transactional
	public void generateCoupon(CouponGenerator coupon) {
		dao.save(coupon);
		
	}




	
	public void createCoupon() {
		char[] chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890".toCharArray();
        StringBuilder sb = new StringBuilder();
        Random random = new SecureRandom();
        for (int i = 0; i < 8; i++) {
            char c = chars[random.nextInt(chars.length)];
            sb.append(c);
        }
        String a = sb.toString();
        System.out.println(a);
        CouponGenerator cap1=new CouponGenerator();
     
        
        	 cap1.setCouponcode(a);
             cap1.setDescription("100discount");
             cap1.setAmount(100d);
          LocalDateTime ld=LocalDateTime.now();
          LocalDateTime nd = ld.plusMonths(2);
         
          String expdate = nd.format(DateTimeFormatter.ofPattern("dd-MM-yyyy hh:mm:ss"));
          cap1.setDate(expdate);
          System.out.println(expdate);
             generateCoupon(cap1);
        
      
       
        
		
	}

	

	
}
