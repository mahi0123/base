package com.cg.app.services;



import com.cg.app.model.CouponGenerator;

public interface CapStoreService {
 void generateCoupon( CouponGenerator coupon);
	void createCoupon();
	
	

}
