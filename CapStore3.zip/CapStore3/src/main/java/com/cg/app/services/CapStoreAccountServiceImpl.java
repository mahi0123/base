package com.cg.app.services;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.app.dao.CapStoreAccountDao;
import com.cg.app.model.CapStoreAccount;
@Service
public class CapStoreAccountServiceImpl implements CapStoreAccountService {
@Autowired CapStoreAccountDao dao;
CapStoreAccount c=new CapStoreAccount();
	@Transactional
	public void createAccount(CapStoreAccount cap) {
		dao.save(cap);
		
	}
	/*@Override
	public void addMoney(String acno,Double amount) {
		c=dao.findById(acno).get();
		double d=c.getBalance();
		d=d+amount;
		c.setBalance(d);
		dao.save(c);
		
	}*/
	@Override
	public void addMoney(String acno1, String acno2, Double amount) {
		
		
	}

}
