package com.cg.app.services;

import com.cg.app.model.CapStoreAccount;

public interface CapStoreAccountService {
	void createAccount(CapStoreAccount cap);
	void addMoney(String acno1,String acno2,Double amount);

}
