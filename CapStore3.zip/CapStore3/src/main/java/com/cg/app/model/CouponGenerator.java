package com.cg.app.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;


@Entity
@Table(name="couponscode")
@XmlRootElement
public class CouponGenerator implements Serializable{
	
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)

	//@Column(name="id")
	//private Integer id;
	
	@Column(name="couponcode")
	private String couponcode;
	
	@Column(name="description")
	private String description;
	
	@Column(name="amount")
	private Double amount;
	
	@Column(name="expdate")
	private String expdate;
	
	
	
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	
	

	public String getDate() {
		return expdate;
	}
	public void setDate(String expdate) {
		this.expdate = expdate;
	}
	
	
	public void setCouponcode(String couponcode) {
		this.couponcode = couponcode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	

}
